"""Frozen archetype regression checks."""
