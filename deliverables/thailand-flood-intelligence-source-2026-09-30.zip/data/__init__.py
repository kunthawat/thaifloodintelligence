"""Data ingestion and normalization."""
